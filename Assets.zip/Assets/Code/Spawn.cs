using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject enemy;
    private bool enemyCreated = false;

    void CreateEnemy()
    {   
        if (!enemyCreated)
        {
        Instantiate(enemy, gameObject.transform.position, gameObject.transform.rotation);
        enemyCreated = true;
        }
    }

    void Start()
    {   
        CreateEnemy();
    }
}