using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class New : MonoBehaviour
{
public class Enemy : MonoBehaviour
{
    private void OnTriggerEnter(Collider other) {
        if (other.name == "Player") {
            
        }
    }
}
}
